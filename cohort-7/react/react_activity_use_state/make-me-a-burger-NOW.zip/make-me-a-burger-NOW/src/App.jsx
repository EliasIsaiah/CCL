import './App.css'
import RudeColor from './components/rude_color'

function App() {
  return (
    <>
      <RudeColor />
    </>
  )
}


export default App
