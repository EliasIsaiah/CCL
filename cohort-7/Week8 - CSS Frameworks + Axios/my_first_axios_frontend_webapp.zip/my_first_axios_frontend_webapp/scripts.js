const button = document.getElementById("button");
const output = document.getElementById("output");
const codeElement = document.createElement("code");

// add an event listener by setting an element's onclick property

button.addEventListener("click", (event) => {
  axios({ url: "https://jsonplaceholder.typicode.com/posts/1" }).then(
    (response) => {
      codeElement.innerText = JSON.stringify(response.data);
      output.appendChild(codeElement);
    }
  );
});

button.addEventListener("click", async (event) => {
  const response = await axios({
    url: "https://jsonplaceholder.typicode.com/posts/1",
  });

  codeElement.innerText = JSON.stringify(response.data);
  output.appendChild(codeElement);
});
