// <div class="emoji">😁</div>;

const addEmojiButton = document.getElementById("add-emoji-btn");
const wrapperDiv = document.getElementById("wrapper");

const emojiDiv = document.createElement("div");
emojiDiv.textContent = "😁";
emojiDiv.classList.add("emoji");

const emojiDiv2 = document.createElement("div");
emojiDiv2.textContent = "😁";
emojiDiv2.classList.add("emoji");

const emojiDiv3 = document.createElement("div");
emojiDiv3.textContent = "😁";
emojiDiv3.classList.add("emoji");

const emojiDiv4 = document.createElement("div");
emojiDiv4.textContent = "😁";
emojiDiv4.classList.add("emoji");

wrapperDiv.prepend(emojiDiv);
wrapperDiv.prepend(emojiDiv2);
wrapperDiv.prepend(emojiDiv3);
wrapperDiv.prepend(emojiDiv4);
