console.log("javascript loaded successfully! 📜");
