import { useEffect, useState } from "react";
import "./App.css";

function App() {
  const [data, setData] = useState();

  async function getData() {
    const response = await fetch("/api/v1/test");
    const responseData = await response.json();
    setData(responseData.message);
  }

  return (
    <>
      <button onClick={() => getData()}>get data</button>
      <h1>Data: {data}</h1>
    </>
  );
}

export default App;
