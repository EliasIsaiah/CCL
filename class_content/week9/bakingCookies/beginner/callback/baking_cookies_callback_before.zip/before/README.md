# bakingCookies with bake time

## Improve upon the given baking cookies program by implementing the concept of bakeTime:
### add a parameter to `bakeCookies` called `bakeTime`
* if bakeTime is > 60, bakeCookies should return:
  * `new Error("that bake time is too long! you'll burn the cookies!")`

## NOTE: the completed `main` function is provided to you. You do not need to modify the main function. Your task is to update the bakeCookies function to achieve the above specified functionality.