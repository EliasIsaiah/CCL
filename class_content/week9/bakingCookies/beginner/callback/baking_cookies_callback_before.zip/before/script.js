function sleep(milliseconds) { // taken from https://rauschma.github.io/async-examples/blocking.html
    const start = Date.now();
    while ((Date.now() - start) < milliseconds);
}

let bakedCookies = "cookies not baked yet";
console.log(bakedCookies);
const BAKE_TIME = 60;

function bakeCookies(callback) {
    sleep(2000);
    callback("🍪🍪🍪");
}

console.log("first console.log!")

function main() {
    console.log("second console.log!")
    bakeCookies(BAKE_TIME, (error, result) => {
        if (error) {
            console.error(error)
        } else {
            bakedCookies = result;
            console.log(`cookies baked! ${bakedCookies}`);
        }
    })
}

main();

console.log("third console.log!")