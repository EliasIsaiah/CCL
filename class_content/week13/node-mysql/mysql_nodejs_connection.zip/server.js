const dotenv = require("dotenv");
const mysql = require("mysql");

dotenv.config();

const connectionDetails = {
    host: 'localhost',
    user: process.env.DB_USER, 
    password: process.env.DB_PASSWORD, 
    database: 'test_schema'
}

const connection = mysql.createConnection(connectionDetails);


connection.connect();

connection.query('SELECT * FROM person', (error, results, fields) => {
    if (error) throw error; 
    results.forEach(person => {
        console.log(`person.id: ${person.id}`);
        console.log(`person.name: ${person.name}`);
        console.log(`person.favorite_color: ${person.favorite_color}`);
        console.log(`person.favorite_food: ${person.favorite_food}`);
        console.log("-----------------------------------------");
    })
});

connection.end();