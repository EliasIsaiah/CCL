const container = document.getElementsByClassName("container")[0];
container.classList.add("red")