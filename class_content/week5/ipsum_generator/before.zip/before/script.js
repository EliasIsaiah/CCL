/**
 * @param {number} numberOfParagraphs
 * @param {number} paragraphSize
 * @returns {string} a string of lorem ipsum text
 */
function generate(numberOfParagraphs, paragraphSize) {
  console.log(numberOfParagraphs, paragraphSize);
}
