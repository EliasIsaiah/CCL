# Exploding Button Goals
## Do this one first
1. I want the font size to increase with the button size

## Advanced Feature
2. I want a button thta grows exponentially rather than linearly

## Stretch Goals/Extra credit
3. I want a reset button that resets the size of the buttons back to their starting size
4. I want a button that changes colors when I click it
5. I want a button that starts big and shrinks when I click it