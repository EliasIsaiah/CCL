# Do you like chocolate?
## We need to know if you like chocolate.
If the user selects the checkbox for chocolate, display the chocolate 🍫 emoji in the emoji display div:
```html 
<div id="emojiDisplay"></div>
```