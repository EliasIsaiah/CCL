let input = document.getElementById("input");
let italicCell = document.getElementById("italic");
let boldCell = document.getElementById("bold");
let codeCell = document.getElementById("code");

input.addEventListener("keyup", (e) => {
  // set the .innerText property to be equal to e.target.vlaue for the three table cells of interest
})