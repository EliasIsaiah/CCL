/**
 * convert temperature units
 * @param {string} temperatureUnitFrom example: "K"
 * @param {string} temperatureUnitTo example: "F"
 * @param {number} value this value you want converted
 * @returns the converted temperature
 */
const temperatureUnitConverter = (temperatureUnitFrom, temperatureUnitTo, value) => {
    return 0;
}

module.exports = {temperatureUnitConverter};