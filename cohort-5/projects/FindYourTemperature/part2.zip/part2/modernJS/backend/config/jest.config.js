/** @type {import('jest').Config} */
const config = {
    transform: {
        '\\.[jt]sx?$': 'babel-jest',
    },
};

export default config;