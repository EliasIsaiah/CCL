set package.json:
```json
{
  "scripts": {
    "test": "jest"
  }
}
```